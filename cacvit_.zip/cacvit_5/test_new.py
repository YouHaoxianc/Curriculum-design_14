import argparse
import datetime
import json
import numpy as np
import os
import time
from pathlib import Path
from PIL import Image
import matplotlib.pyplot as plt
import scipy.ndimage as ndimage

import torch
import torch.nn as nn
import torch.backends.cudnn as cudnn
from torch.utils.data import Dataset
import torchvision
from torchvision import transforms
import torchvision.transforms.functional as TF

import timm

assert timm.__version__ == "0.3.2"  # version check
import pandas as pd
import util.misc as misc
import math
import models.CntVit_3layers_scalepos_patchmat_withr_plain as CntVit
from val import val_func

def get_args_parser():
    parser = argparse.ArgumentParser('MAE pre-training', add_help=False)
    parser.add_argument('--batch_size', default=1, type=int,
                        help='Batch size per GPU (effective batch size is batch_size * accum_iter * # gpus')
    parser.add_argument('--epochs', default=1, type=int)
    parser.add_argument('--accum_iter', default=1, type=int,
                        help='Accumulate gradient iterations (for increasing the effective batch size under memory constraints)')

    # Model parameters
    parser.add_argument('--model', default='mae_vit_base_patch16', type=str, metavar='MODEL',
                        help='Name of model to train')
    parser.add_argument('--mode', default='GlobalAttention', type=str, metavar='MODE',
                        help='mode to train')
    parser.add_argument('--decodemode', default='GlobalAttention', type=str, metavar='DECODEMODE',
                        help='mode of decoder to train')
    parser.add_argument('--similarityfunc', default='PatchConv', type=str, metavar='DECODEMODE',
                        help='mode of decoder to train')
    parser.add_argument('--similaritymode', default='OutputAdd', type=str, metavar='DECODEMODE',
                        help='mode of decoder to train')
    parser.add_argument('--gamma', default=True, type=bool, metavar='DECODEMODE',
                        help='mode of decoder to train')

    parser.add_argument('--mask_ratio', default=0.5, type=float,
                        help='Masking ratio (percentage of removed patches).')

    parser.add_argument('--norm_pix_loss', action='store_true',
                        help='Use (per-patch) normalized pixels as targets for computing loss')
    parser.set_defaults(norm_pix_loss=False)

    # Optimizer parameters
    parser.add_argument('--weight_decay', type=float, default=0.05,
                        help='weight decay (default: 0.05)')

    parser.add_argument('--lr', type=float, default=None, metavar='LR',
                        help='learning rate (absolute lr)')
    parser.add_argument('--blr', type=float, default=1e-3, metavar='LR',
                        help='base learning rate: absolute_lr = base_lr * total_batch_size / 256')
    parser.add_argument('--min_lr', type=float, default=0., metavar='LR',
                        help='lower lr bound for cyclic schedulers that hit 0')

    parser.add_argument('--warmup_epochs', type=int, default=10, metavar='N',
                        help='epochs to warmup LR')

    parser.add_argument('--output_dir', default='./Image',
                        help='path where to save, empty for no saving')
    parser.add_argument('--log_dir', default='./Image',
                        help='path where to tensorboard log')
    parser.add_argument('--device', default='cuda:0',
                        help='device to use for training / testing')
    parser.add_argument('--seed', default=0, type=int)
    parser.add_argument('--resume', default="/data/lixuebing/cacvit/output_0415/checkpoint-139.pth",
                        help='resume from checkpoint')

    parser.add_argument('--start_epoch', default=0, type=int, metavar='N',
                        help='start epoch')
    parser.add_argument('--num_workers', default=10, type=int)
    parser.add_argument('--pin_mem', action='store_true',
                        help='Pin CPU memory in DataLoader for more efficient (sometimes) transfer to GPU.')
    parser.add_argument('--no_pin_mem', action='store_false', dest='pin_mem')
    parser.set_defaults(pin_mem=True)

    # distributed training parameters
    parser.add_argument('--world_size', default=1, type=int,
                        help='number of distributed processes')
    parser.add_argument('--local_rank', default=-1, type=int)
    parser.add_argument('--dist_on_itp', action='store_true')
    parser.add_argument('--dist_url', default='env://',
                        help='url used to set up distributed training')

    return parser


MAX_W = 384
# load data from FSC147
data_path = '/home/lixuebing/learning/dataset_no_img/'
data_split_file = data_path + 'dataset.csv'
IM_NORM_MEAN = [0.485, 0.456, 0.406]
IM_NORM_STD = [0.229, 0.224, 0.225]
annotations = {}
class_dict = {}
data_split = {'train': [], 'val': [], 'test': []}
data_fold_split = {'train': [], 'val': [], 'test': []}
data_split_csv = pd.read_csv(data_split_file)
for i in range(len(data_split_csv)):
    key_split = data_split_csv['split'][i]
    labelpath = data_path + data_split_csv['variety'][i] + '/' + data_split_csv['foldname'][i] + '/labels/'
    imgpath = data_path + data_split_csv['variety'][i] + '/' + data_split_csv['foldname'][i] + '/images/'
    for img in os.listdir(imgpath):
        value_split = data_split_csv['variety'][i] + '/' + data_split_csv['foldname'][i] + '/images/' + img
        data_split[key_split].append(value_split)
        class_dict[value_split] = data_split_csv['variety'][i] + '/' + data_split_csv['foldname'][i]

    for file in os.listdir(labelpath):
        data_fold_csv = pd.read_csv(labelpath + file)
        for k in range(len(data_fold_csv)):
            key_fold = data_split_csv['variety'][i] + '/' + data_split_csv['foldname'][i] + '/images/' + \
                       data_fold_csv['filename'][k]
            if key_fold not in annotations:
                annotations[key_fold] = {'box_examples_coordinates': [], 'points': []}
            if data_fold_csv['region_shape_attributes'][k].find("rect") != -1:
                placex1 = data_fold_csv['region_shape_attributes'][k].find(":", 9)
                placex2 = data_fold_csv['region_shape_attributes'][k].find(",", placex1)
                placey1 = data_fold_csv['region_shape_attributes'][k].find(":", placex2)
                placey2 = data_fold_csv['region_shape_attributes'][k].find(",", placey1)
                placew1 = data_fold_csv['region_shape_attributes'][k].find(":", placey2)
                placew2 = data_fold_csv['region_shape_attributes'][k].find(",", placew1)
                placeh1 = data_fold_csv['region_shape_attributes'][k].find(":", placew2)
                placeh2 = data_fold_csv['region_shape_attributes'][k].find("}", placeh1)
                x1 = round(float(data_fold_csv['region_shape_attributes'][k][placex1 + 1:placex2]))
                y1 = round(float(data_fold_csv['region_shape_attributes'][k][placey1 + 1:placey2]))
                w = round(float(data_fold_csv['region_shape_attributes'][k][placew1 + 1:placew2]))
                h = round(float(data_fold_csv['region_shape_attributes'][k][placeh1 + 1:placeh2]))
                x2 = x1 + w
                y2 = y1 + h
                annotations[key_fold]['box_examples_coordinates'].append([[x1, y1], [x1, y2], [x2, y2], [x2, y1]])
            elif data_fold_csv['region_shape_attributes'][k].find("point") != -1:
                placex1 = data_fold_csv['region_shape_attributes'][k].find(":", 9)
                placex2 = data_fold_csv['region_shape_attributes'][k].find(",", placex1)
                placey1 = data_fold_csv['region_shape_attributes'][k].find(":", placex2)
                placey2 = data_fold_csv['region_shape_attributes'][k].find("}", placey1)
                x1 = round(float(data_fold_csv['region_shape_attributes'][k][placex1 + 1:placex2]))
                y1 = round(float(data_fold_csv['region_shape_attributes'][k][placey1 + 1:placey2]))
                annotations[key_fold]['points'].append([x1, y1])


class TestData(Dataset):
    def __init__(self, dataset='val'):
        self.img = data_split[dataset]
        self.img_dir = data_path

    def __len__(self):
        return len(self.img)

    def __getitem__(self, idx):
        im_id = self.img[idx]
        anno = annotations[im_id]
        bboxes = anno['box_examples_coordinates']

        dots = np.array(anno['points'])

        image = Image.open('{}{}'.format(data_path, im_id))

        w, h = image.size
        image.load()
        t_flag = 0
        if w < h:
            image = image.transpose(Image.TRANSPOSE)
            t_flag = 1
        w, h = image.size
        newh = MAX_W
        resize_ratio = newh / h
        neww = math.ceil(w * resize_ratio)

        image = image.resize((neww, newh), resample=Image.BICUBIC)

        W, H = image.size

        new_H = 16 * int(H / 16)
        new_W = 16 * int(W / 16)
        scale_factor_w = float(new_W) / w
        scale_factor_h = float(new_H) / h
        image = transforms.Resize((new_H, new_W))(image)
        Normalize = transforms.Compose([transforms.ToTensor()])
        image = Normalize(image)

        rects = list()
        if t_flag == 0:
            for bbox in bboxes:
                x1 = round(bbox[0][0] * scale_factor_w)
                y1 = round(bbox[0][1] * scale_factor_h)
                x2 = round(bbox[2][0] * scale_factor_w)
                y2 = round(bbox[2][1] * scale_factor_h)
                rects.append([y1, x1, y2, x2])
        else:
            for bbox in bboxes:
                y1 = round(bbox[0][0] * scale_factor_w)
                x1 = round(bbox[0][1] * scale_factor_h)
                y2 = round(bbox[2][0] * scale_factor_w)
                x2 = round(bbox[2][1] * scale_factor_h)
                rects.append([y1, x1, y2, x2])

        boxes = list()
        scale_x = []
        scale_y = []
        cnt = 0
        w_all = 0
        h_all = 0
        for box in rects:
            cnt += 1
            if cnt > 3:
                break
            box2 = [int(k) for k in box]
            y1, x1, y2, x2 = box2[0], box2[1], box2[2], box2[3]
            scale_x1 = torch.tensor((x2 - x1 + 1) / 384)
            scale_x.append(scale_x1)
            scale_y1 = torch.tensor((y2 - y1 + 1) / 384)
            scale_y.append(scale_y1)
            bbox = image[:, y1:y2 + 1, x1:x2 + 1]
            bbox = transforms.Resize((64, 64))(bbox)
            boxes.append(bbox.numpy())
            w_all = float(x2 - x1) + w_all
            h_all = float(y2 - y1) + w_all
        scale_xx = torch.stack(scale_x).unsqueeze(-1)
        scale_yy = torch.stack(scale_y).unsqueeze(-1)
        scale = torch.cat((scale_xx, scale_yy), dim=1)
        boxes = np.array(boxes)
        boxes = torch.Tensor(boxes)

        w_all = w_all / 60
        h_all = h_all / 60

        gt_map = np.zeros((new_H, new_W), dtype='float32')

        if t_flag == 1:
            for i in range(dots.shape[0]):
                ptx = float(dots[i][1])
                pty = float(dots[i][0])
                dots[i][0] = ptx * scale_factor_w
                dots[i][1] = pty * scale_factor_h
                gt_map[min(round(float(dots[i][1])), new_H - 1)][
                    min(round(float(dots[i][0])), new_W - 1)] = 1
        else:
            for i in range(dots.shape[0]):
                dots[i][0] = float(dots[i][0]) * scale_factor_w
                dots[i][1] = float(dots[i][1]) * scale_factor_h
                gt_map[min(round(float(dots[i][1])), new_H - 1)][
                    min(round(float(dots[i][0])), new_W - 1)] = 1

        gt_map = ndimage.gaussian_filter(gt_map, sigma=(h_all, w_all), order=0)
        gt_map = torch.from_numpy(gt_map)
        gt_map = gt_map * 60

        sample = {'image': image, 'dots': dots, 'boxes': boxes, 'pos': rects, 'gt_map': gt_map, 'scale': scale,
                  'density': gt_map}
        return sample['image'], sample['density'], sample['dots'], sample['boxes'], sample['pos'], sample[
            'gt_map'], im_id, sample['scale']

def main(args):
    misc.init_distributed_mode(args)

    print('job dir: {}'.format(os.path.dirname(os.path.realpath(__file__))))
    print("{}".format(args).replace(', ', ',\n'))

    device = torch.device(args.device)

    # fix the seed for reproducibility
    seed = args.seed + misc.get_rank()
    torch.manual_seed(seed)
    np.random.seed(seed)

    cudnn.benchmark = True

    dataset_test = TestData()
    print(dataset_test)

    if True:  # args.distributed:
        num_tasks = misc.get_world_size()
        global_rank = misc.get_rank()
        sampler_test = torch.utils.data.DistributedSampler(
            dataset_test, num_replicas=num_tasks, rank=global_rank, shuffle=False
        )
        print("Sampler_test = %s" % str(sampler_test))
    else:
        sampler_test = torch.utils.data.RandomSampler(dataset_test)

    data_loader_test = torch.utils.data.DataLoader(
        dataset_test, sampler=sampler_test,
        batch_size=1,
        num_workers=args.num_workers,
        pin_memory=args.pin_mem,
        drop_last=False,
    )
    
    # define the model
     # define the model
    model = CntVit.__dict__[args.model](norm_pix_loss=args.norm_pix_loss,mode = args.mode, decodemode=args.decodemode, 
                                        similarityfunc = args.similarityfunc,similaritymode = args.similaritymode,gamma = args.gamma)

    model.to(device)

    model_without_ddp = model

    # print("Model = %s" % str(model_without_ddp))

    if args.distributed:
        model = torch.nn.parallel.DistributedDataParallel(model, device_ids=[args.gpu], find_unused_parameters=True)
        model_without_ddp = model.module

    misc.load_model_FSC(args=args, model_without_ddp=model_without_ddp)

    print(f"Start testing.")
    start_time = time.time()
    
    # test
    epoch = 0
    model.eval()
    metric_logger = misc.MetricLogger(delimiter="  ")
    header = 'Epoch: [{}]'.format(epoch)
    print_freq = 20

    # some parameters in training
    train_mae = 0
    train_rmse = 0
    pred_cnt = 0
    gt_cnt = 0

    loss_array = []
    gt_array = []
    wrong_id = []

    i = 0
    # mae_new,mse_new = val_func(model=model,device=device,dataset='test')
    # print(mae_new,mse_new)
    loss_value = 0
    begin_w = 768 - int(MAX_W)
    for data_iter_step, (samples, gt_density, gt_dots, boxes, pos, gt_map, im_id, scale) in enumerate(
            metric_logger.log_every(data_loader_test, print_freq, header)):
        samples = samples.to(device, non_blocking=True)
        gt_dots = gt_dots.to(device, non_blocking=True).half()
        boxes = boxes.to(device, non_blocking=True)
        scale = scale.to(device, non_blocking=True)
        gt_density = gt_density.to(device, non_blocking=True)
        pos = pos
        gt_map = gt_map.to(device, non_blocking=True)
        output_merge = []
        _, _, h, w = samples.shape
        pred_cnt = 0
        with torch.no_grad():
            times = math.floor(w / 192)
            with torch.no_grad():
                for i in range(times - 1):
                    input_x = [samples[:, :, :384, i * 192:(i * 192 + 384)], boxes, scale]
                    output = model(input_x)
                    if times == 2:
                        pred_cnt += (output).sum().item() / 60
                        output_merge.append(output)
                    else:
                        if i == 0:
                            pred_cnt += (output[:, :, :192]).sum().item() / 60 + (
                                output[:, :, 192:]).sum().item() / 120
                            output_merge.append(output[:, :, :192])
                            output_merge.append(output[:, :, 192:] / 2)
                        elif i == times - 2:
                            pred_cnt += (output[:, :, :192]).sum().item() / 120 + (
                                output[:, :, 192:]).sum().item() / 60
                            output_merge[i] = output_merge[i] + output[:, :, :192] / 2
                            output_merge.append(output[:, :, 192:])
                        else:
                            pred_cnt += (output).sum().item() / 120
                            output_merge[i] = output_merge[i] + output[:, :, :192] / 2
                            output_merge.append(output[:, :, 192:] / 2)
                if w % 192 != 0:
                    input_x = [samples[:, :, :384, -384:], boxes, scale]
                    output = model(input_x)
                    last_w = int((times * 192 - w + 384))
                    pred_cnt += (output[:, :, last_w:]).sum().item() / 60
                    output_merge.append(output[:, :, last_w:])
                for i in range(times - 1):
                    input_xx = [samples[:, :, -384:, i * 192:(i * 192 + 384)], boxes, scale]
                    output = model(input_xx)
                    if times == 2:
                        pred_cnt += (output[:, begin_w:, :] / 60).sum().item()
                        output_merge[0] = torch.cat((output_merge[0], output[:, begin_w:, :]), dim=-2)
                    else:
                        if i == 0:
                            pred_cnt += (output[:, begin_w:, :192] / 60).sum().item() + (
                                    output[:, begin_w:, 192:] / 60).sum().item() / 2
                            output_merge[i] = torch.cat((output_merge[i], output[:, begin_w:, :192]), dim=-2)
                            output_merge[i + 1] = torch.cat((output_merge[i + 1], output[:, begin_w:, 192:] / 2),
                                                            dim=-2)
                            # output_merge.append(output[:, :, :192])
                            # output_merge.append(output[:, :, 192:]/2)
                        elif i == times - 2:
                            pred_cnt += (output[:, begin_w:, :192] / 60).sum().item() / 2 + (
                                    output[:, begin_w:, 192:] / 60).sum().item()
                            output_merge[i][:, 384:, :] = output_merge[i][:, 384:, :] + output[:, begin_w:,
                                                                                        :192] / 2
                            # output_merge[i]=output_merge[i]+output[:, :, :192] / 2
                            output_merge[i + 1] = torch.cat((output_merge[i + 1], output[:, begin_w:, 192:]), dim=-2)
                            # output_merge.append(output[:, :, 192:])
                        else:
                            pred_cnt += (output[:, begin_w:, :] / 60).sum().item() / 2
                            output_merge[i][:, 384:, :] = output_merge[i][:, 384:, :] + output[:, begin_w:,
                                                                                        :192] / 2
                            # output_merge[i]=output_merge[i]+output[:, :, :192] / 2
                            output_merge[i + 1] = torch.cat((output_merge[i + 1], output[:, begin_w:, 192:] / 2),
                                                            dim=-2)
                            # output_merge.append(output[:, :, 192:] / 2)
                if w % 192 != 0:
                    input_x = [samples[:, :, -384:, -384:], boxes, scale]
                    output = model(input_x)
                    last_w = int((times * 192 - w + 384))
                    pred_cnt += (output[:, begin_w:, last_w:] / 60).sum().item()
                    output_merge[-1] = torch.cat((output_merge[-1], output[:, begin_w:, last_w:]), dim=-2)
                    # output_merge.append(output[:, :, last_w:])
            output_merge = torch.cat(output_merge, dim=-1)
            gt_cnt = gt_dots.shape[1]
            cnt_err = abs(pred_cnt - gt_cnt)
            loss = (output_merge - gt_density)
            loss = loss.type(torch.float32)
            loss = loss ** 2
            loss = (loss / (384 * 384))
            loss = loss.sum() / output_merge.shape[0]
            loss_value += loss.item()
        if cnt_err > 40:
            # misc.draw_result(samples,output_merge,im_id)
            print(im_id)
        train_mae += cnt_err
        train_rmse += cnt_err ** 2
        print(
            f'{data_iter_step}/{len(data_loader_test)}: pred_cnt: {pred_cnt},  gt_cnt: {gt_cnt},  error: {cnt_err},  AE: {cnt_err},  SE: {cnt_err ** 2} ')

        loss_array.append(cnt_err)
        gt_array.append(gt_cnt)

        torch.cuda.synchronize(device=0)

    metric_logger.synchronize_between_processes()
    print("Averaged stats:", metric_logger)
    
    log_stats = {'MAE': train_mae/(len(data_loader_test)),
                'RMSE':  (train_rmse/(len(data_loader_test)))**0.5}

    print('Current MAE: {:5.2f}, RMSE: {:5.2f} '.format( train_mae/(len(data_loader_test)), (train_rmse/(len(data_loader_test)))**0.5))

    if args.output_dir and misc.is_main_process():
        with open(os.path.join(args.output_dir, "log.txt"), mode="a", encoding="utf-8") as f:
            f.write(json.dumps(log_stats) + "\n")

    plt.scatter(gt_array, loss_array)
    plt.xlabel('Ground Truth')
    plt.ylabel('Error')
    plt.savefig(f'./Image/test_stat.png')
    plt.show()

    total_time = time.time() - start_time
    total_time_str = str(datetime.timedelta(seconds=int(total_time)))
    print('Testing time {}'.format(total_time_str))

if __name__ == '__main__':
    os.environ['CUDA_VISIBLE_DEVICES'] = '0'
    args = get_args_parser()
    args = args.parse_args()
    if args.output_dir:
        Path(args.output_dir).mkdir(parents=True, exist_ok=True)
    main(args)
