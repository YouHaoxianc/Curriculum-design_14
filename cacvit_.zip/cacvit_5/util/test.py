data_path = 'W:/workspace/BMnet/BMnet/data_list/'
im_dir = data_path + 'images_384_VarV2'

anno_file = data_path + 'annotation_FSC147_384.json'
data_split_file = data_path + 'Train_Test_Val_FSC_147.json'
class_file = data_path + 'ImageClasses_FSC147.txt'