"""
FSC-147 dataset
The exemplar boxes are sampled and resized to the same size
"""
from torch.utils.data import Dataset
import os
from PIL import Image
from PIL import ImageDraw
import json
import torch
import numpy as np
from torchvision.transforms import transforms
import pandas as pd
import scipy.ndimage as ndimage
import imgaug.augmenters as iaa
import numpy as np
import random
from torchvision import transforms
import torch
import cv2
import os
import pandas as pd
import torchvision.transforms.functional as TF
import scipy.ndimage as ndimage
from PIL import Image
import math
import imgaug as ia
import imgaug.augmenters as iaa
from imgaug.augmentables import Keypoint, KeypointsOnImage
from imgaug.augmentables import Keypoint, KeypointsOnImage
import cv2
import random


def get_image_classes(class_file):
    class_dict = dict()
    with open(class_file, 'r') as f:
        classes = [line.split('\t') for line in f.readlines()]

    for entry in classes:
        class_dict[entry[0]] = entry[1]

    return class_dict

def batch_collate_fn(batch):
    batch = list(zip(*batch))
    batch[0], scale_embedding, batch[2] = batch_padding(batch[0], batch[2])
    patches = torch.stack(batch[1], dim=0)
    batch[1] = {'patches': patches, 'scale_embedding': scale_embedding.long()}
    return tuple(batch)

def _max_by_axis(the_list):
    maxes = the_list[0]
    for sublist in the_list[1:]:
        for index, item in enumerate(sublist):
            maxes[index] = max(maxes[index], item)
    return maxes

def batch_padding(tensor_list, target_dict):
    if tensor_list[0].ndim == 3:
        max_size = _max_by_axis([list(img.shape) for img in tensor_list])
        batch_shape = [len(tensor_list)] + max_size
        density_shape = [len(tensor_list)] + [1, max_size[1], max_size[2]]
        b, c, h, w = batch_shape
        dtype = tensor_list[0].dtype
        device = tensor_list[0].device
        tensor = torch.zeros(batch_shape, dtype=dtype, device=device)
        density_map = torch.zeros(density_shape, dtype=dtype, device=device)
        pt_map = torch.zeros(density_shape, dtype=dtype, device=device)
        gtcount = []
        scale_embedding = []
        for idx, package  in enumerate(zip(tensor_list, tensor, density_map, pt_map)):
            img, pad_img, pad_density, pad_pt_map = package
            pad_img[: img.shape[0], : img.shape[1], : img.shape[2]].copy_(img)
            pad_density[:, : img.shape[1], : img.shape[2]].copy_(target_dict[idx]['density_map'])
            pad_pt_map[:, : img.shape[1], : img.shape[2]].copy_(target_dict[idx]['pt_map'])
            gtcount.append(target_dict[idx]['gtcount'])
            scale_embedding.append(target_dict[idx]['scale_embedding'])
        target = {'density_map': density_map,
                  'pt_map': pt_map,
                  'gtcount': torch.tensor(gtcount)}
    else:
        raise ValueError('not supported')
    return tensor, torch.stack(scale_embedding), target

class FSC147Dataset(Dataset):
    def __init__(self, data_dir, data_list, scaling, box_number=3, scale_number=60, min_size=384, max_size=1584,
                 preload=True, main_transform=None, query_transform=None):
        self.data_dir = data_dir
        self.scaling = scaling
        self.box_number = box_number
        self.scale_number = scale_number
        self.preload = preload
        self.query_transform = query_transform
        self.min_size = min_size
        self.max_size = max_size
        # load annotations for the entire dataset
        # annotation_file = os.path.join(self.data_dir, 'annotation_FSC147_384.json')
        # image_classes_file = os.path.join(self.data_dir, 'ImageClasses_FSC147.txt')

        # self.image_classes = get_image_classes(image_classes_file)

        annotations = {}
        class_dict = {}
        data_split = {'train': [], 'val': [], 'test': []}
        data_split_csv = pd.read_csv(data_dir+'dataset.csv')
        for i in range(len(data_split_csv)):
            key_split = data_split_csv['split'][i]
            labelpath = data_dir + data_split_csv['variety'][i] + '/' + data_split_csv['foldname'][i] + '/labels/'
            imgpath = data_dir + data_split_csv['variety'][i] + '/' + data_split_csv['foldname'][i] + '/images/'
            for img in os.listdir(imgpath):
                value_split = data_split_csv['variety'][i] + '/' + data_split_csv['foldname'][i] + '/images/' + img
                data_split[key_split].append(value_split)
                class_dict[value_split] = data_split_csv['variety'][i] + '/' + data_split_csv['foldname'][i]

            for file in os.listdir(labelpath):
                data_fold_csv = pd.read_csv(labelpath + file)
                for k in range(len(data_fold_csv)):
                    key_fold = data_split_csv['variety'][i] + '/' + data_split_csv['foldname'][i] + '/images/' + \
                               data_fold_csv['filename'][k]
                    if key_fold not in annotations:
                        annotations[key_fold] = {'box_examples_coordinates': [], 'points': []}
                    if data_fold_csv['region_shape_attributes'][k].find("rect") != -1:
                        placex1 = data_fold_csv['region_shape_attributes'][k].find(":", 9)
                        placex2 = data_fold_csv['region_shape_attributes'][k].find(",", placex1)
                        placey1 = data_fold_csv['region_shape_attributes'][k].find(":", placex2)
                        placey2 = data_fold_csv['region_shape_attributes'][k].find(",", placey1)
                        placew1 = data_fold_csv['region_shape_attributes'][k].find(":", placey2)
                        placew2 = data_fold_csv['region_shape_attributes'][k].find(",", placew1)
                        placeh1 = data_fold_csv['region_shape_attributes'][k].find(":", placew2)
                        placeh2 = data_fold_csv['region_shape_attributes'][k].find("}", placeh1)
                        x1 = round(float(data_fold_csv['region_shape_attributes'][k][placex1 + 1:placex2]))
                        y1 = round(float(data_fold_csv['region_shape_attributes'][k][placey1 + 1:placey2]))
                        w = round(float(data_fold_csv['region_shape_attributes'][k][placew1 + 1:placew2]))
                        h = round(float(data_fold_csv['region_shape_attributes'][k][placeh1 + 1:placeh2]))
                        x2 = x1 + w
                        y2 = y1 + h
                        annotations[key_fold]['box_examples_coordinates'].append(
                            [[x1, y1], [x1, y2], [x2, y2], [x2, y1]])
                    elif data_fold_csv['region_shape_attributes'][k].find("point") != -1:
                        placex1 = data_fold_csv['region_shape_attributes'][k].find(":", 9)
                        placex2 = data_fold_csv['region_shape_attributes'][k].find(",", placex1)
                        placey1 = data_fold_csv['region_shape_attributes'][k].find(":", placex2)
                        placey2 = data_fold_csv['region_shape_attributes'][k].find("}", placey1)
                        x1 = round(float(data_fold_csv['region_shape_attributes'][k][placex1 + 1:placex2]))
                        y1 = round(float(data_fold_csv['region_shape_attributes'][k][placey1 + 1:placey2]))
                        annotations[key_fold]['points'].append([x1, y1])

        self.annotations = annotations
        self.data_list = data_split[data_list]
        self.data_type = data_list
        self.class_dict = class_dict
        self.scale_number = scale_number
        self.preload = preload
        self.main_transform = main_transform
        self.query_transform = query_transform
        self.min_size = min_size
        self.max_size = max_size
        # store images and generate ground truths
        self.images = {}
        self.targets = {}
        self.patches = {}


    def __len__(self):
        return len(self.data_list)

    def __getitem__(self, idx):
        file_name = self.data_list[idx]

        if file_name in self.images:
            img = self.images[file_name]
            target = self.targets[file_name]
            patches = self.patches[file_name]
            
        else:
            image_path = os.path.join(self.data_dir, file_name)
            t_flag = 0
            img_info = self.annotations[file_name]
            img = Image.open(image_path).convert("RGB")
            w, h = img.size
            if w < h:
                img = img.transpose(Image.TRANSPOSE)
                t_flag = 1
            w, h = img.size
            # resize the image
            nh = int(384/8) * 8
            rh = nh / h
            nw = round(round(max(w*rh, 384))/8) * 8
            rw = nw/w
            img = img.resize((nw, nh), resample=Image.BICUBIC)
            pt_map = np.zeros((nh, nw), dtype=np.int32)

            points = np.array(img_info['points'], dtype=np.uint32)
            if t_flag == 1:
                for i in range(points.shape[0]):
                    ptx = float(points[i][1])
                    pty = float(points[i][0])
                    points[i][0] = ptx * rw
                    points[i][1] = pty * rh
            else:
                for i in range(points.shape[0]):
                    points[i][0] = float(points[i][0]) * rw
                    points[i][1] = float(points[i][1]) * rh

            boxes = np.array(img_info['box_examples_coordinates'], dtype=np.uint32)
            if t_flag == 0:
                for bbox in boxes:
                    bbox[0][0] = round(bbox[0][0] * rw)
                    bbox[0][1] = round(bbox[0][1] * rh)
                    bbox[2][0] = round(bbox[2][0] * rw)
                    bbox[2][1] = round(bbox[2][1] * rh)
            else:
                for bbox in boxes:
                    y1 = round(bbox[0][0] * rw)
                    x1 = round(bbox[0][1] * rh)
                    y2 = round(bbox[2][0] * rw)
                    x2 = round(bbox[2][1] * rh)
                    bbox[0][1] = y1
                    bbox[0][0] = x1
                    bbox[2][1] = y2
                    bbox[2][0] = x2

            gtcount = points.shape[0]
            
            # crop patches and data transformation
            target = dict()
            patches = []
            scale_embedding = []

            density_map = np.zeros((nh, nw), dtype='float32')
            for i in range(points.shape[0]):
                density_map[min(nh - 1, round(points[i][1]))][min(nw - 1, round(points[i][0]))] = 1

            h_all = 0
            w_all = 0
            # print('boxes:', boxes.shape[0])
            if points.shape[0] > 0:
                points[:, 0] = np.clip(points[:, 0], 0, nw - 1)
                points[:, 1] = np.clip(points[:, 1], 0, nh - 1)
                pt_map[points[:, 1], points[:, 0]] = 1
                for box in boxes:
                    x1, y1 = box[0].astype(np.int32)
                    x2, y2 = box[2].astype(np.int32)
                    w_all += x2 - x1
                    h_all += y2 - y1
                    patch = img.crop((x1, y1, x2, y2))
                    patches.append(self.query_transform(patch))
                    # calculate scale
                    scale = (x2 - x1) / nw * 0.5 + (y2 - y1) / nh * 0.5
                    scale = scale // (0.5 / self.scale_number)
                    scale = scale if scale < self.scale_number - 1 else self.scale_number - 1
                    scale_embedding.append(scale)

            w_all = w_all / 60
            h_all = h_all / 60
            density_map = ndimage.gaussian_filter(density_map, sigma=(h_all, w_all), order=0)

            target['density_map'] = density_map * self.scaling
            target['pt_map'] = pt_map
            target['gtcount'] = gtcount
            target['scale_embedding'] = torch.tensor(scale_embedding)

            img, target = self.main_transform(img, target)
            patches = torch.stack(patches, dim=0)

            if self.preload:
                self.images.update({file_name: img})
                self.patches.update({file_name: patches})
                self.targets.update({file_name: target})

        return img, patches, target

def pad_to_constant(inputs, psize):
    h, w = inputs.size()[-2:]
    ph, pw = (psize - h % psize), (psize - w % psize)
    # print(ph,pw)

    (pl, pr) = (pw // 2, pw - pw // 2) if pw != psize else (0, 0)
    (pt, pb) = (ph // 2, ph - ph // 2) if ph != psize else (0, 0)
    if (ph != psize) or (pw != psize):
        tmp_pad = [pl, pr, pt, pb]
        # print(tmp_pad)
        inputs = torch.nn.functional.pad(inputs, tmp_pad)

    return inputs

class MainTransform(object):
    def __init__(self):
        self.img_trans = transforms.Compose(
            [transforms.ToTensor(), transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])

    def __call__(self, img, target):
        img = self.img_trans(img)
        density_map = target['density_map']
        pt_map = target['pt_map']
        pt_map = torch.from_numpy(pt_map).unsqueeze(0)
        density_map = torch.from_numpy(density_map).unsqueeze(0)

        img = pad_to_constant(img, 32)
        density_map = pad_to_constant(density_map, 32)
        pt_map = pad_to_constant(pt_map, 32)
        target['density_map'] = density_map.float()
        target['pt_map'] = pt_map.float()

        return img, target

def get_query_transforms(is_train, exemplar_size):
    if is_train:
        # SimCLR style augmentation
        return transforms.Compose([
            transforms.Resize(exemplar_size),
            # transforms.RandomApply([
            #    transforms.ColorJitter(0.4, 0.4, 0.4, 0.1)  # not strengthened
            # ], p=0.8),
            # transforms.RandomGrayscale(p=0.2),
            # transforms.RandomApply([GaussianBlur([.1, 2.])], p=0.5),
            transforms.ToTensor(),
            # transforms.RandomHorizontalFlip(),  HorizontalFlip may cause the pretext too difficult, so we remove it
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                 std=[0.229, 0.224, 0.225])
        ])
    else:
        return transforms.Compose([
            transforms.Resize(exemplar_size),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                 std=[0.229, 0.224, 0.225])
        ])

def build_dataset(cfg, is_train):
    main_transform = MainTransform()
    query_transform = get_query_transforms(is_train, cfg.DATASET.exemplar_size)
    if is_train:
        data_list = cfg.DATASET.list_train
    else:
        if not cfg.VAL.evaluate_only:
            data_list = cfg.DATASET.list_val
        else:
            data_list = cfg.DATASET.list_test

    dataset = FSC147Dataset(data_dir=cfg.DIR.dataset,
                            data_list=data_list,
                            scaling=1.0,
                            box_number=cfg.DATASET.exemplar_number,
                            scale_number=cfg.MODEL.ep_scale_number,
                            main_transform=main_transform,
                            query_transform=query_transform)

    return dataset

if __name__ == '__main__':
    from torch.utils.data import DataLoader
    main_transform = MainTransform()
    query_transform = get_query_transforms(is_train=True, exemplar_size=(128, 128))

    dataset = FSC147Dataset(data_dir='D:/dataset/FSC147/',
                            data_list='D:/dataset/FSC147/train.txt',
                            scaling=1.0,
                            main_transform=main_transform,
                            query_transform=query_transform)

    data_loader = DataLoader(dataset, batch_size=5, collate_fn=batch_collate_fn)

    for idx, sample in enumerate(data_loader):
        img, patches, targets = sample
        print(img.shape)
        print(patches.keys())
        print(targets.keys())
        break

