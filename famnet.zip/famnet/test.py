#!/usr/bin/env python
# coding: utf-8

"""
Test code written by Viresh Ranjan

Last modified by: Minh Hoai Nguyen (minhhoai@cs.stonybrook.edu)
Date: 2021/04/19
"""

import copy
from model import CountRegressor, Resnet50FPN
from utils import MAPS, Scales, Transform, extract_features
from utils import MincountLoss, PerturbationLoss
from PIL import Image
import os
import cv2
import torch
import argparse
import json
import numpy as np
from tqdm import tqdm
import pandas as pd
from torchvision import transforms
from os.path import exists
import torch.optim as optim
import torch.nn.functional as F
from einops import rearrange
import matplotlib.pyplot as plt
parser = argparse.ArgumentParser(description="Few Shot Counting Evaluation code")
parser.add_argument("-dp", "--data_path", type=str, default='/home/lixuebing/learning/dataset_no_img/', help="Path to the FSC147 dataset")
parser.add_argument("-ts", "--test_split", type=str, default='val', choices=["val_PartA","val_PartB","test_PartA","test_PartB","test", "val"], help="what data split to evaluate on")
parser.add_argument("-m",  "--model_path", type=str, default="/home/lixuebing/learning/famnet/logsSave/FamNet.pth", help="path to trained model")
parser.add_argument("-a",  "--adapt", action='store_true', help="If specified, perform test time adaptation")
parser.add_argument("-gs", "--gradient_steps", type=int,default=100, help="number of gradient steps for the adaptation")
parser.add_argument("-lr", "--learning_rate", type=float,default=1e-7, help="learning rate for adaptation")
parser.add_argument("-wm", "--weight_mincount", type=float,default=1e-9, help="weight multiplier for Mincount Loss")
parser.add_argument("-wp", "--weight_perturbation", type=float,default=1e-4, help="weight multiplier for Perturbation Loss")
parser.add_argument("-g",  "--gpu-id", type=int, default=2, help="GPU id. Default 0 for the first GPU. Use -1 for CPU.")
args = parser.parse_args()

data_path = args.data_path
data_split_file = data_path + 'dataset.csv'

if not torch.cuda.is_available() or args.gpu_id < 0:
    use_gpu = False
    print("===> Using CPU mode.")
else:
    use_gpu = True
    os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
    os.environ["CUDA_VISIBLE_DEVICES"] = str(args.gpu_id)

resnet50_conv = Resnet50FPN()
if use_gpu: resnet50_conv.cuda()
resnet50_conv.eval()

regressor = CountRegressor(6, pool='mean')
regressor.load_state_dict(torch.load(args.model_path))
if use_gpu: regressor.cuda()
regressor.eval()

annotations = {}
class_dict = {}
data_split = {'train': [], 'val': [], 'test': []}
data_fold_split = {'train': [], 'val': [], 'test': []}
data_split_csv = pd.read_csv(data_split_file)
for i in range(len(data_split_csv)):
    key_split = data_split_csv['split'][i]
    labelpath = data_path + data_split_csv['variety'][i] + '/' + data_split_csv['foldname'][i] + '/labels/'
    imgpath = data_path + data_split_csv['variety'][i] + '/' + data_split_csv['foldname'][i] + '/images/'
    for img in os.listdir(imgpath):
        value_split = data_split_csv['variety'][i] + '/' + data_split_csv['foldname'][i] + '/images/' + img
        data_split[key_split].append(value_split)
        class_dict[value_split] = data_split_csv['variety'][i] + '/' + data_split_csv['foldname'][i]

    for file in os.listdir(labelpath):
        data_fold_csv = pd.read_csv(labelpath + file)
        for k in range(len(data_fold_csv)):
            key_fold = data_split_csv['variety'][i] + '/' + data_split_csv['foldname'][i] + '/images/' + \
                       data_fold_csv['filename'][k]
            if key_fold not in annotations:
                annotations[key_fold] = {'box_examples_coordinates': [], 'points': []}
            if data_fold_csv['region_shape_attributes'][k].find("rect") != -1:
                placex1 = data_fold_csv['region_shape_attributes'][k].find(":", 9)
                placex2 = data_fold_csv['region_shape_attributes'][k].find(",", placex1)
                placey1 = data_fold_csv['region_shape_attributes'][k].find(":", placex2)
                placey2 = data_fold_csv['region_shape_attributes'][k].find(",", placey1)
                placew1 = data_fold_csv['region_shape_attributes'][k].find(":", placey2)
                placew2 = data_fold_csv['region_shape_attributes'][k].find(",", placew1)
                placeh1 = data_fold_csv['region_shape_attributes'][k].find(":", placew2)
                placeh2 = data_fold_csv['region_shape_attributes'][k].find("}", placeh1)
                x1 = round(float(data_fold_csv['region_shape_attributes'][k][placex1 + 1:placex2]))
                y1 = round(float(data_fold_csv['region_shape_attributes'][k][placey1 + 1:placey2]))
                w = round(float(data_fold_csv['region_shape_attributes'][k][placew1 + 1:placew2]))
                h = round(float(data_fold_csv['region_shape_attributes'][k][placeh1 + 1:placeh2]))
                x2 = x1 + w
                y2 = y1 + h
                annotations[key_fold]['box_examples_coordinates'].append([[x1, y1], [x1, y2], [x2, y2], [x2, y1]])
            elif data_fold_csv['region_shape_attributes'][k].find("point") != -1:
                placex1 = data_fold_csv['region_shape_attributes'][k].find(":", 9)
                placex2 = data_fold_csv['region_shape_attributes'][k].find(",", placex1)
                placey1 = data_fold_csv['region_shape_attributes'][k].find(":", placex2)
                placey2 = data_fold_csv['region_shape_attributes'][k].find("}", placey1)
                x1 = round(float(data_fold_csv['region_shape_attributes'][k][placex1 + 1:placex2]))
                y1 = round(float(data_fold_csv['region_shape_attributes'][k][placey1 + 1:placey2]))
                annotations[key_fold]['points'].append([x1, y1])



cnt = 0
SAE = 0  # sum of absolute errors
SSE = 0  # sum of square errors

def draw_result(samples, mask, im_id):
    w, h = samples.size
    samples = np.array(samples)
    samples = samples.astype('uint8')

    mask = mask.squeeze(0).squeeze(0).cpu().clone().numpy()

    norm_img2 = np.zeros(mask.shape)
    norm_img2 = cv2.normalize(mask, norm_img2, 0, 255, cv2.NORM_MINMAX)
    norm_img2 = np.asarray(norm_img2, dtype=np.uint8)

    heat_img = cv2.applyColorMap(norm_img2, cv2.COLORMAP_JET) # 注意此处的三通道热力图是cv2专有的GBR排列
    heat_img = cv2.cvtColor(heat_img, cv2.COLOR_BGR2RGB) # 将BGR图像转为RGB图像

    combine = cv2.addWeighted(cv2.resize(samples,(w,h)),0.5,cv2.resize(heat_img,(w,h)),0.5,0)
    plt.figure(dpi=800)
    plt.imshow(combine)
    plt.axis('off')
    im_id = im_id.split("/")
    pth = "./result/" + im_id[0] + im_id[-1]
    plt.savefig(pth,bbox_inches='tight')
    plt.close()


print("Evaluation on {} data".format(args.test_split))
im_ids = data_split[args.test_split]
pbar = tqdm(im_ids)
for im_id in pbar:
    anno = annotations[im_id]
    bboxes = anno['box_examples_coordinates']
    dots = np.array(anno['points'])

    rects = list()
    t_flag = 0

    image = Image.open('{}{}'.format(data_path, im_id))
    w, h = image.size
    if w < h:
        image = image.transpose(Image.TRANSPOSE)
        t_flag = 1
    w, h = image.size
    resize_ratio = 1

    newh = round(384 / 8)*8
    rh = newh / h
    neww = round(round(max(w * rh, 384)) / 8) * 8

    image = image.resize((neww, newh), resample=Image.BICUBIC)
    image.load()
    imgg=image
    resize_ratio_w = neww / w
    resize_ratio_h = newh / h

    rects = list()
    if t_flag == 0:
        for bbox in bboxes:
            x1 = round(bbox[0][0] * resize_ratio_w)
            y1 = round(bbox[0][1] * resize_ratio_h)
            x2 = round(bbox[2][0] * resize_ratio_w)
            y2 = round(bbox[2][1] * resize_ratio_h)
            rects.append([y1, x1, y2, x2])
    else:
        for bbox in bboxes:
            x1 = round(bbox[0][1] * resize_ratio_w)
            y1 = round(bbox[0][0] * resize_ratio_h)
            x2 = round(bbox[2][1] * resize_ratio_w)
            y2 = round(bbox[2][0] * resize_ratio_h)
            rects.append([y1, x1, y2, x2])
    if t_flag == 1:
        for i in range(dots.shape[0]):
            ptx = float(dots[i][1])
            pty = float(dots[i][0])
            dots[i][0] = ptx * resize_ratio_w
            dots[i][1] = pty * resize_ratio_h
    else:
        for i in range(dots.shape[0]):
            dots[i][0] = float(dots[i][0]) * resize_ratio_w
            dots[i][1] = float(dots[i][1]) * resize_ratio_h
    sample = {'image':image, 'lines_boxes':rects}
    sample = Transform(sample)
    image, boxes = sample['image'], sample['boxes']

    if use_gpu:
        image = image.cuda()
        boxes = boxes.cuda()

    with torch.no_grad(): features = extract_features(resnet50_conv, image.unsqueeze(0), boxes.unsqueeze(0), MAPS, Scales)

    if not args.adapt:
        with torch.no_grad(): output = regressor(features)
    else:
        features.required_grad = True
        adapted_regressor = copy.deepcopy(regressor)
        adapted_regressor.train()
        optimizer = optim.Adam(adapted_regressor.parameters(), lr=args.learning_rate)
        for step in range(0, args.gradient_steps):
            optimizer.zero_grad()
            output = adapted_regressor(features)
            lCount = args.weight_mincount * MincountLoss(output, boxes)
            lPerturbation = args.weight_perturbation * PerturbationLoss(output, boxes, sigma=8)
            Loss = lCount + lPerturbation
            # loss can become zero in some cases, where loss is a 0 valued scalar and not a tensor
            # So Perform gradient descent only for non zero cases
            if torch.is_tensor(Loss):
                Loss.backward()
                optimizer.step()
        features.required_grad = False
        output = adapted_regressor(features)
    # draw_result(imgg, output, im_id)
    gt_cnt = dots.shape[0]
    pred_cnt = output.sum().item()/60
    cnt = cnt + 1
    err = abs(gt_cnt - pred_cnt)
    SAE += err
    SSE += err**2

    pbar.set_description('{:<8}: actual-predicted: {:6d}, {:6.1f}, error: {:6.1f}. Current MAE: {:5.2f}, RMSE: {:5.2f}'.\
                         format(im_id, gt_cnt, pred_cnt, abs(pred_cnt - gt_cnt), SAE/cnt, (SSE/cnt)**0.5))
    print("")

print('On {} data, MAE: {:6.2f}, RMSE: {:6.2f}'.format(args.test_split, SAE/cnt, (SSE/cnt)**0.5))

