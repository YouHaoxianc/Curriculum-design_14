"""
Training Code for Learning To Count Everything, CVPR 2021
Authors: Viresh Ranjan,Udbhav, Thu Nguyen, Minh Hoai

Last modified by: Minh Hoai Nguyen (minhhoai@cs.stonybrook.edu)
Date: 2021/04/19
"""
import torch.nn as nn
from model import  Resnet50FPN,CountRegressor,weights_normal_init
from utils import MAPS, Scales, Transform,TransformTrain,extract_features, visualize_output_and_save
from PIL import Image
import os
import utils
import scipy.ndimage as ndimage
import torch
import argparse
import math
import cv2
import json
import numpy as np
from tqdm import tqdm
from os.path import exists,join
import random
import torch.optim as optim

from PIL import ImageDraw
import torch.nn.functional as F
import pandas as pd

parser = argparse.ArgumentParser(description="Few Shot Counting Evaluation code")
parser.add_argument("-dp", "--data_path", type=str, default='/home/lixuebing/learning/dataset_no_img/', help="Path to the FSC147 dataset")
parser.add_argument("-o", "--output_dir", type=str,default="./logsSave", help="/Path/to/output/logs/")
parser.add_argument("-ts", "--test-split", type=str, default='val', choices=["train", "test", "val"], help="what data split to evaluate on on")
parser.add_argument("-ep", "--epochs", type=int,default=500, help="number of training epochs")
parser.add_argument("-g", "--gpu", type=int,default=0, help="GPU id")
parser.add_argument("-s", "--seed", type=int,default=400322, help="seed")
parser.add_argument("-lr", "--learning-rate", type=float,default=1e-5, help="learning rate")
args = parser.parse_args()


data_path = args.data_path
data_split_file = data_path + 'dataset.csv'

if not exists(args.output_dir):
    os.mkdir(args.output_dir)

os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = str(args.gpu)

criterion = nn.MSELoss().cuda()

resnet50_conv = Resnet50FPN()
resnet50_conv.cuda()
resnet50_conv.eval()

regressor = CountRegressor(6, pool='mean')
weights_normal_init(regressor, dev=0.001)
regressor.train()
regressor.cuda()
optimizer = optim.Adam(regressor.parameters(), lr = args.learning_rate)

annotations = {}
class_dict = {}
data_split = {'train': [], 'val': [], 'test': []}
data_fold_split = {'train': [], 'val': [], 'test': []}
data_split_csv = pd.read_csv(data_split_file)
for i in range(len(data_split_csv)):
    key_split = data_split_csv['split'][i]
    labelpath = data_path + data_split_csv['variety'][i] + '/' + data_split_csv['foldname'][i] + '/labels/'
    imgpath = data_path + data_split_csv['variety'][i] + '/' + data_split_csv['foldname'][i] + '/images/'
    for img in os.listdir(imgpath):
        value_split = data_split_csv['variety'][i] + '/' + data_split_csv['foldname'][i] + '/images/' + img
        data_split[key_split].append(value_split)
        class_dict[value_split] = data_split_csv['variety'][i] + '/' + data_split_csv['foldname'][i]

    for file in os.listdir(labelpath):
        data_fold_csv = pd.read_csv(labelpath + file)
        for k in range(len(data_fold_csv)):
            key_fold = data_split_csv['variety'][i] + '/' + data_split_csv['foldname'][i] + '/images/' + \
                       data_fold_csv['filename'][k]
            if key_fold not in annotations:
                annotations[key_fold] = {'box_examples_coordinates': [], 'points': []}
            if data_fold_csv['region_shape_attributes'][k].find("rect") != -1:
                placex1 = data_fold_csv['region_shape_attributes'][k].find(":", 9)
                placex2 = data_fold_csv['region_shape_attributes'][k].find(",", placex1)
                placey1 = data_fold_csv['region_shape_attributes'][k].find(":", placex2)
                placey2 = data_fold_csv['region_shape_attributes'][k].find(",", placey1)
                placew1 = data_fold_csv['region_shape_attributes'][k].find(":", placey2)
                placew2 = data_fold_csv['region_shape_attributes'][k].find(",", placew1)
                placeh1 = data_fold_csv['region_shape_attributes'][k].find(":", placew2)
                placeh2 = data_fold_csv['region_shape_attributes'][k].find("}", placeh1)
                x1 = round(float(data_fold_csv['region_shape_attributes'][k][placex1 + 1:placex2]))
                y1 = round(float(data_fold_csv['region_shape_attributes'][k][placey1 + 1:placey2]))
                w = round(float(data_fold_csv['region_shape_attributes'][k][placew1 + 1:placew2]))
                h = round(float(data_fold_csv['region_shape_attributes'][k][placeh1 + 1:placeh2]))
                x2 = x1 + w
                y2 = y1 + h
                annotations[key_fold]['box_examples_coordinates'].append([[x1, y1], [x1, y2], [x2, y2], [x2, y1]])
            elif data_fold_csv['region_shape_attributes'][k].find("point") != -1:
                placex1 = data_fold_csv['region_shape_attributes'][k].find(":", 9)
                placex2 = data_fold_csv['region_shape_attributes'][k].find(",", placex1)
                placey1 = data_fold_csv['region_shape_attributes'][k].find(":", placex2)
                placey2 = data_fold_csv['region_shape_attributes'][k].find("}", placey1)
                x1 = round(float(data_fold_csv['region_shape_attributes'][k][placex1 + 1:placex2]))
                y1 = round(float(data_fold_csv['region_shape_attributes'][k][placey1 + 1:placey2]))
                annotations[key_fold]['points'].append([x1, y1])


def train():
    print("Training on FSC147 train set data")
    im_ids = data_split['train']
    seed = args.seed
    torch.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    random.shuffle(im_ids)
    train_mae = 0
    train_rmse = 0
    train_loss = 0
    pbar = tqdm(im_ids)
    cnt = 0
    for im_id in pbar:
        cnt += 1
        anno = annotations[im_id]
        bboxes = anno['box_examples_coordinates']
        dots = np.array(anno['points'])
        t_flag = 0

        image = Image.open('{}{}'.format(data_path, im_id))
        w,h = image.size
        if w < h:
            image = image.transpose(Image.TRANSPOSE)
            t_flag = 1
        w, h = image.size
        resize_ratio = 1

        newh = int(384 / 8) * 8
        rh = newh / h
        neww = round(round(max(w * rh, 384)) / 8) * 8

        image = image.resize((neww, newh), resample=Image.BICUBIC)
        image.load()
        resize_ratio_w = neww / w
        resize_ratio_h = newh / h

        h_all = 0
        w_all = 0
        rects = list()
        if t_flag == 0:
            for bbox in bboxes:
                x1 = round(bbox[0][0] * resize_ratio_w)
                y1 = round(bbox[0][1] * resize_ratio_h)
                x2 = round(bbox[2][0] * resize_ratio_w)
                y2 = round(bbox[2][1] * resize_ratio_h)
                h_all = h_all + y2-y1
                w_all = w_all + x2-x1
                rects.append([y1, x1, y2, x2])
        else:
            for bbox in bboxes:
                x1 = round(bbox[0][1] * resize_ratio_w)
                y1 = round(bbox[0][0] * resize_ratio_h)
                x2 = round(bbox[2][1] * resize_ratio_w)
                y2 = round(bbox[2][0] * resize_ratio_h)
                h_all = h_all + y2-y1
                w_all = w_all + x2-x1
                rects.append([y1, x1, y2, x2])
        h_all = h_all/60
        w_all = w_all/60

        gt_map = np.zeros((newh, neww), dtype='float32')
        if t_flag == 1:
            for i in range(dots.shape[0]):
                ptx = float(dots[i][1])
                pty = float(dots[i][0])
                dots[i][0] = ptx * resize_ratio_w
                dots[i][1] = pty * resize_ratio_h
                gt_map[min(round(float(dots[i][1])), newh - 1)][
                    min(round(float(dots[i][0])), neww - 1)] = 1
        else:
            for i in range(dots.shape[0]):
                dots[i][0] = float(dots[i][0]) * resize_ratio_w
                dots[i][1] = float(dots[i][1]) * resize_ratio_h
                gt_map[min(round(float(dots[i][1])), newh - 1)][
                    min(round(float(dots[i][0])), neww - 1)] = 1
        gt_map = ndimage.gaussian_filter(gt_map, sigma=(h_all, w_all), order=0)
        gt_map = torch.from_numpy(gt_map)
        density = gt_map * 60
        density = np.array(density)
        sample = {'image':image,'lines_boxes':rects,'gt_density':density}
        sample = TransformTrain(sample)

        image, boxes,gt_density = sample['image'].cuda(), sample['boxes'].cuda(),sample['gt_density'].cuda()

        with torch.no_grad():
            features = extract_features(resnet50_conv, image.unsqueeze(0), boxes.unsqueeze(0),  MAPS, Scales)
        features.requires_grad = True
        optimizer.zero_grad()
        output = regressor(features)

        #if image size isn't divisible by 8, gt size is slightly different from output size
        if output.shape[2] != gt_density.shape[2] or output.shape[3] != gt_density.shape[3]:
            orig_count = gt_density.sum().detach().item()
            gt_density = F.interpolate(gt_density, size=(output.shape[2],output.shape[3]),mode='bilinear')
            new_count = gt_density.sum().detach().item()
            if new_count > 0: gt_density = gt_density * (orig_count / new_count)
        loss = criterion(output, gt_density)
        loss.backward()
        optimizer.step()
        train_loss += loss.item()
        pred_cnt = torch.sum(output/60).item()
        gt_cnt = torch.sum(gt_density/60).item()
        cnt_err = abs(pred_cnt - gt_cnt)
        train_mae += cnt_err
        train_rmse += cnt_err ** 2
        if cnt % 10 == 0:
            print('gt-pred: {:6.1f}, {:6.1f}, error: {:6.1f}. Current MAE: {:5.2f}, RMSE: {:5.2f} Best VAL MAE: {:5.2f}, RMSE: {:5.2f}'.format(gt_cnt, pred_cnt, abs(pred_cnt - gt_cnt), train_mae/cnt, (train_rmse/cnt)**0.5,best_mae,best_rmse))
            print("")
    train_loss = train_loss / len(im_ids)
    train_mae = (train_mae / len(im_ids))
    train_rmse = (train_rmse / len(im_ids))**0.5
    return train_loss,train_mae,train_rmse




def eval():
    cnt = 0
    SAE = 0 # sum of absolute errors
    SSE = 0 # sum of square errors

    print("Evaluation on {} data".format(args.test_split))
    im_ids = data_split[args.test_split]
    pbar = tqdm(im_ids)
    for im_id in pbar:
        anno = annotations[im_id]
        bboxes = anno['box_examples_coordinates']
        dots = np.array(anno['points'])

        rects = list()

        t_flag = 0

        image = Image.open('{}{}'.format(data_path, im_id))
        w,h = image.size
        if w < h:
            image = image.transpose(Image.TRANSPOSE)
            t_flag = 1
        w, h = image.size

        newh = 500
        rh = newh / h
        neww = round(round(w * rh) / 8) * 8

        image = image.resize((neww, newh), resample=Image.BICUBIC)
        image.load()
        resize_ratio_w = neww / w
        resize_ratio_h = newh / h


        rects = list()
        if t_flag == 0:
            for bbox in bboxes:
                x1 = round(bbox[0][0] * resize_ratio_w)
                y1 = round(bbox[0][1] * resize_ratio_h)
                x2 = round(bbox[2][0] * resize_ratio_w)
                y2 = round(bbox[2][1] * resize_ratio_h)
                rects.append([y1, x1, y2, x2])
        else:
            for bbox in bboxes:
                x1 = round(bbox[0][1] * resize_ratio_w)
                y1 = round(bbox[0][0] * resize_ratio_h)
                x2 = round(bbox[2][1] * resize_ratio_w)
                y2 = round(bbox[2][0] * resize_ratio_h)
                rects.append([y1, x1, y2, x2])
        if t_flag == 1:
            for i in range(dots.shape[0]):
                ptx = float(dots[i][1])
                pty = float(dots[i][0])
                dots[i][0] = ptx * resize_ratio_w
                dots[i][1] = pty * resize_ratio_h
        else:
            for i in range(dots.shape[0]):
                dots[i][0] = float(dots[i][0]) * resize_ratio_w
                dots[i][1] = float(dots[i][1]) * resize_ratio_h
        sample = {'image':image,'lines_boxes':rects}

        sample = Transform(sample)
        image, boxes = sample['image'].cuda(), sample['boxes'].cuda()

        with torch.no_grad():
            output = regressor(extract_features(resnet50_conv, image.unsqueeze(0), boxes.unsqueeze(0), MAPS, Scales))

        gt_cnt = dots.shape[0]
        pred_cnt = (output.sum().item())/20
        cnt = cnt + 1
        err = abs(gt_cnt - pred_cnt)
        SAE += err
        SSE += err**2

        pbar.set_description('{:<8}: actual-predicted: {:6d}, {:6.1f}, error: {:6.1f}. Current MAE: {:5.2f}, RMSE: {:5.2f}'.format(im_id, gt_cnt, pred_cnt, abs(pred_cnt - gt_cnt), SAE/cnt, (SSE/cnt)**0.5))
        print("")

    print('On {} data, MAE: {:6.2f}, RMSE: {:6.2f}'.format(args.test_split, SAE/cnt, (SSE/cnt)**0.5))
    return SAE/cnt, (SSE/cnt)**0.5


best_mae, best_rmse = 1e7, 1e7
stats = list()
loss_list=[]
val_mae_list=[]
for epoch in range(0,args.epochs):
    regressor.train()
    train_loss,train_mae,train_rmse = train()
    regressor.eval()
    val_mae,val_rmse = eval()
    stats.append((train_loss, train_mae, train_rmse, val_mae, val_rmse))
    stats_file = join(args.output_dir, "stats" +  ".txt")
    with open(stats_file, 'w') as f:
        for s in stats:
            f.write("%s\n" % ','.join([str(x) for x in s]))    
    if best_mae >= val_mae:
        best_mae = val_mae
        best_rmse = val_rmse
        model_name = args.output_dir + '/' + "FamNet.pth"
        torch.save(regressor.state_dict(), model_name)
    loss_list.append(float(stats[-1][0]))
    val_mae_list.append((float(stats[-1][3])))
    utils.plot_learning_curves(loss_list, val_mae_list, args.output_dir)
    print("Epoch {}, Avg. Epoch Loss: {} Train MAE: {} Train RMSE: {} Val MAE: {} Val RMSE: {} Best Val MAE: {} Best Val RMSE: {} ".format(
              epoch+1,  stats[-1][0], stats[-1][1], stats[-1][2], stats[-1][3], stats[-1][4], best_mae, best_rmse))
    




